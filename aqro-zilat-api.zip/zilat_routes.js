const express = require('express');
const router = express.Router();
const { verifyBelief } = require('./zilat_controller');

router.post('/verify', verifyBelief);

module.exports = router;