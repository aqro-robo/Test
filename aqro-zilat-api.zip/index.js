const express = require('express');
const app = express();
const cors = require('cors');
const zilatRoutes = require('./zilat_routes');

app.use(cors());
app.use(express.json());
app.use('/api/zilat', zilatRoutes);

const PORT = process.env.PORT || 8009;
app.listen(PORT, () => {
  console.log(`Zilat API running on port ${PORT}`);
});