exports.verifyBelief = (req, res) => {
  const { belief } = req.body;

  if (!belief) {
    return res.status(400).json({ error: 'No belief provided.' });
  }

  // تحلیل طعنه‌آمیز و منطقی
  const analysis = `Analyzing belief: "${belief}"... 🤨

Result:
This seems like one of those myths that never stood the test of logic.
Try science instead of superstition. 📚✨`;

  res.json({ analysis });
};