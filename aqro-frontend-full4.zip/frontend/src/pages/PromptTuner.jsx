import React from 'react';
export default function PromptTuner() {
  return <div><h2>PromptTuner Page</h2></div>;
}