import { useState } from 'react';
import axios from 'axios';

export default function Mivara() {
  const [feeling, setFeeling] = useState('');
  const [response, setResponse] = useState('');

  const getAdvice = async () => {
    if (!feeling) return;
    const res = await axios.post('/api/mivara/advice', { feeling });
    setResponse(res.data.response);
  };

  return (
    <div>
      <h2>🧠 Mivara - Emotional Support</h2>
      <textarea value={feeling} onChange={e => setFeeling(e.target.value)} placeholder="Describe how you feel..."></textarea>
      <br />
      <button onClick={getAdvice}>Get Support</button>
      <pre>{response}</pre>
    </div>
  );
}