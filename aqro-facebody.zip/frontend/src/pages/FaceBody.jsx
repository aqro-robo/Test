import { useState } from 'react';
import axios from 'axios';

export default function FaceBody() {
  const [form, setForm] = useState({
    name: '', age: '', gender: '', traits: ''
  });

  const [modelURL, setModelURL] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const generate = async () => {
    const res = await axios.post('/api/facebody/model', form, { responseType: 'blob' });
    const url = URL.createObjectURL(res.data);
    setModelURL(url);
  };

  return (
    <div>
      <h2>🧬 Face & Body AI</h2>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="age" placeholder="Age" onChange={handleChange} />
      <input name="gender" placeholder="Gender" onChange={handleChange} />
      <input name="traits" placeholder="Traits (comma-separated)" onChange={handleChange} />
      <button onClick={generate}>Generate Model</button>
      {modelURL && <a href={modelURL} download="model.glb">Download 3D Model</a>}
    </div>
  );
}