const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const suggestBusiness = async (req, res) => {
  const { name, age, skills, interests, location } = req.body;
  if (!name || !age || !skills || !interests || !location) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const prompt = `
Name: ${name}
Age: ${age}
Skills: ${skills}
Interests: ${interests}
Location: ${location}

Based on this profile, suggest 3 business ideas or income methods personalized for this person. Include a short explanation for each.
`;

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }]
    });

    const ideas = gptRes.data.choices[0].message.content;
    res.json({ ideas });
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate suggestions' });
  }
};

module.exports = { suggestBusiness };