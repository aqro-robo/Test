const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const emotionalAdvice = async (req, res) => {
  const { feeling } = req.body;
  if (!feeling) return res.status(400).json({ error: 'Feeling required' });

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{
        role: 'user',
        content: `As a kind and thoughtful emotional support AI, give a helpful and empathetic response to this feeling: "${feeling}". Include validation, understanding, and practical advice.`
      }]
    });

    const response = gptRes.data.choices[0].message.content;
    res.json({ response });
  } catch (err) {
    res.status(500).json({ error: 'Advice generation failed' });
  }
};

module.exports = { emotionalAdvice };