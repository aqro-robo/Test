const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const suggestMusic = async (req, res) => {
  const { mood } = req.body;
  if (!mood) return res.status(400).json({ error: 'Mood is required' });

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{
        role: 'user',
        content: `Suggest 5 music tracks for the mood: "${mood}". Format: Song - Artist - Genre.`
      }]
    });

    const suggestions = gptRes.data.choices[0].message.content;
    res.json({ suggestions });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch music suggestions' });
  }
};

module.exports = { suggestMusic };