const fs = require('fs');
const path = require('path');

const generateModel = async (req, res) => {
  const { name, age, gender, traits } = req.body;
  if (!name || !age || !gender || !traits) {
    return res.status(400).json({ error: 'All fields required' });
  }

  try {
    const fakeGLB = fs.readFileSync(path.join(__dirname, '../data/sample_model.glb'));
    res.setHeader('Content-Type', 'model/gltf-binary');
    res.send(fakeGLB);
  } catch (err) {
    res.status(500).json({ error: 'Model generation failed' });
  }
};

module.exports = { generateModel };