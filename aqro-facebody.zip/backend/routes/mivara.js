const express = require('express');
const router = express.Router();
const { emotionalAdvice } = require('../controllers/mivaraController');

router.post('/advice', emotionalAdvice);

module.exports = router;