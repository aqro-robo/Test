const express = require('express');
const router = express.Router();
const { generateModel } = require('../controllers/facebodyController');

router.post('/model', generateModel);

module.exports = router;