const express = require('express');
const router = express.Router();
const { securityAdvice } = require('../controllers/zentroxController');

router.post('/tools', securityAdvice);

module.exports = router;