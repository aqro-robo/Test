const express = require('express');
const router = express.Router();
const { searchAnswer } = require('../controllers/sayraController');

router.post('/search', searchAnswer);

module.exports = router;