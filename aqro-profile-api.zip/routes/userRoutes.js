const express = require('express');
const router = express.Router();

let userData = {
  id: 'user123',
  name: 'Armin R',
  email: 'armin@aqro.io',
  location: 'Tehran',
  balance: 320,
  favoriteRobot: 'Petros'
};

router.get('/info', (req, res) => {
  res.json(userData);
});

router.post('/update', (req, res) => {
  const updates = req.body;
  userData = { ...userData, ...updates };
  res.json({ success: true, updated: userData });
});

module.exports = router;
