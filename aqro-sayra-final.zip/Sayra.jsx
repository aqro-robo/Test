import React, { useState } from 'react';

const Sayra = () => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState(null);

  const handleSearch = async () => {
    const res = await fetch('https://aqro.io/api/sayra/search?q=' + encodeURIComponent(query));
    const data = await res.json();
    setResponse(data);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Sayra – Smart Search</h1>
      <input 
        type="text" 
        value={query} 
        onChange={(e) => setQuery(e.target.value)} 
        placeholder="Type something..." 
        style={{ padding: 10, width: '300px' }}
      />
      <button onClick={handleSearch} style={{ marginLeft: 10, padding: 10 }}>
        Search
      </button>
      <div style={{ marginTop: 20 }}>
        {response && <pre>{JSON.stringify(response, null, 2)}</pre>}
      </div>
    </div>
  );
};

export default Sayra;
