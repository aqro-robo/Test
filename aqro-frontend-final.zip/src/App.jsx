import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Petros from './pages/Petros';
import Reela from './pages/Reela';
import Drox from './pages/Drox';
import Sayra from './pages/Sayra';
import Nava from './pages/Nava';
import Zentrox from './pages/Zentrox';
import Zilat from './pages/Zilat';
import Azra from './pages/Azra';
import Mivara from './pages/Mivara';
import FaceBody from './pages/FaceBody';
import PromptTuner from './pages/PromptTuner';
import Auth from './pages/Auth';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Petros />} />
        <Route path="/reela" element={<Reela />} />
        <Route path="/drox" element={<Drox />} />
        <Route path="/sayra" element={<Sayra />} />
        <Route path="/nava" element={<Nava />} />
        <Route path="/zentrox" element={<Zentrox />} />
        <Route path="/zilat" element={<Zilat />} />
        <Route path="/azra" element={<Azra />} />
        <Route path="/mivara" element={<Mivara />} />
        <Route path="/facebody" element={<FaceBody />} />
        <Route path="/prompt" element={<PromptTuner />} />
        <Route path="/auth" element={<Auth />} />
      </Routes>
    </Router>
  );
}

export default App;