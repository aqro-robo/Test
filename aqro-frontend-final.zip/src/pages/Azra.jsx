import React from 'react';
export default function Azra() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Azra - Financial AI</h1>
      <p>Track crypto markets and get personalized wealth suggestions.</p>
    </div>
  );
}