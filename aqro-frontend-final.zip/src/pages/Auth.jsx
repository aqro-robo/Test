import React from 'react';
export default function Auth() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Authentication</h1>
      <p>Register, login, or authenticate users here.</p>
    </div>
  );
}