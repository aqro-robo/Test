import React from 'react';
export default function Drox() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Drox - Betting System</h1>
      <p>Manage challenges and competitions with token-based bets.</p>
    </div>
  );
}