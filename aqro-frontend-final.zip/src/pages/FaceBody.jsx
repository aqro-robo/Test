import React from 'react';
export default function FaceBody() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Face & Body AI</h1>
      <p>Analyze and generate your digital face and body.</p>
    </div>
  );
}