import React from 'react';
export default function Zilat() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Zilat - Truth Seeker</h1>
      <p>Enter a superstition to get a logical, scientific analysis.</p>
    </div>
  );
}