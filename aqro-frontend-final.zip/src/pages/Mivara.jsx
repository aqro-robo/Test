import React from 'react';
export default function Mivara() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Mivara - Emotional Companion</h1>
      <p>Private chats and emotional support with full privacy.</p>
    </div>
  );
}