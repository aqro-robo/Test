import React from 'react';
export default function Zentrox() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Zentrox - Profit Advisor</h1>
      <p>Location-based business suggestions and income strategies.</p>
    </div>
  );
}