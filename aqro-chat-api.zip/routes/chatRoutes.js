const express = require('express');
const router = express.Router();

let messages = [];

router.get('/:user1/:user2', (req, res) => {
  const { user1, user2 } = req.params;
  const filtered = messages.filter(
    m =>
      (m.from === user1 && m.to === user2) ||
      (m.from === user2 && m.to === user1)
  );
  res.json(filtered);
});

router.post('/', (req, res) => {
  const { from, to, text } = req.body;
  const newMessage = { from, to, text, time: new Date().toISOString() };
  messages.push(newMessage);
  res.json({ success: true, message: newMessage });
});

module.exports = router;
