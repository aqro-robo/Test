const express = require('express');
const cors = require('cors');
const app = express();
const port = 6000;

const chatRoutes = require('./routes/chatRoutes');

app.use(cors());
app.use(express.json());
app.use('/api/chat', chatRoutes);

app.listen(port, () => {
  console.log(`💬 Chat API running at http://localhost:${port}`);
});
