#!/bin/bash
npm install --prefix frontend
npm start --prefix frontend