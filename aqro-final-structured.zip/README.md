# Aqro Final Structured
This package includes the full frontend and backend API structure.