import React, { useState } from 'react';
import axios from 'axios';

export default function AzraAdvisorPage() {
  const [form, setForm] = useState({
    name: '', age: '', city: '', skills: '', goal: ''
  });
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const getAdvice = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/azra/advise', form);
      setResponse(res.data.advice);
    } catch (err) {
      setResponse('❌ خطا در دریافت پیشنهاد.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">💼 Azra – ربات مشاور مالی و ثروت</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <input name="name" value={form.name} onChange={handleChange} placeholder="نام" className="p-2 bg-gray-800 rounded" />
        <input name="age" value={form.age} onChange={handleChange} placeholder="سن" className="p-2 bg-gray-800 rounded" />
        <input name="city" value={form.city} onChange={handleChange} placeholder="شهر" className="p-2 bg-gray-800 rounded" />
        <input name="skills" value={form.skills} onChange={handleChange} placeholder="تخصص‌ها" className="p-2 bg-gray-800 rounded" />
        <input name="goal" value={form.goal} onChange={handleChange} placeholder="هدف مالی" className="p-2 bg-gray-800 rounded" />
      </div>

      <button
        onClick={getAdvice}
        disabled={loading}
        className="bg-green-600 hover:bg-green-700 p-2 rounded mb-6"
      >
        {loading ? '⏳ تحلیل...' : '📊 دریافت پیشنهاد Azra'}
      </button>

      {response && (
        <div className="bg-gray-900 p-4 rounded text-green-300 whitespace-pre-wrap">
          {response}
        </div>
      )}
    </div>
  );
}