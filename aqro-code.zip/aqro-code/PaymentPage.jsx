import React, { useState } from 'react';
import axios from 'axios';

export default function PaymentPage() {
  const [wallet, setWallet] = useState('');
  const [amount, setAmount] = useState('');
  const [productId, setProductId] = useState('badge_special_001');
  const [result, setResult] = useState(null);

  const handlePay = async () => {
    try {
      const res = await axios.post('/api/payment/pay', {
        buyerWallet: wallet,
        amount,
        productId
      });
      setResult({ success: true, hash: res.data.txHash });
    } catch (err) {
      setResult({ success: false, message: err.response?.data?.error || err.message });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-10">
      <h1 className="text-3xl font-bold mb-6">💸 خرید با PTR</h1>

      <div className="max-w-md mx-auto">
        <label className="block mb-2">آدرس کیف پول:</label>
        <input type="text" value={wallet} onChange={e => setWallet(e.target.value)} className="w-full p-2 mb-4 bg-gray-800 rounded" />

        <label className="block mb-2">مقدار PTR:</label>
        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-2 mb-4 bg-gray-800 rounded" />

        <label className="block mb-2">کد محصول:</label>
        <input type="text" value={productId} onChange={e => setProductId(e.target.value)} className="w-full p-2 mb-6 bg-gray-800 rounded" />

        <button onClick={handlePay} className="w-full bg-blue-600 hover:bg-blue-700 p-2 rounded text-white font-semibold">پرداخت</button>

        {result && (
          <div className="mt-6 p-4 bg-gray-900 border border-gray-700 rounded">
            {result.success ? (
              <div>
                <p className="text-green-400">✅ پرداخت موفق!</p>
                <p>Tx Hash: {result.hash}</p>
              </div>
            ) : (
              <p className="text-red-400">❌ خطا: {result.message}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}