// backend/api/prompt/promptTune.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/tune', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const refinePrompt = `
Improve the following prompt for clarity, creativity, and effectiveness in use with GPT:
---
${prompt}
---
Respond only with the improved version of the prompt.
`;

  try {
    const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4",
      messages: [{ role: "user", content: refinePrompt }],
      temperature: 0.7
    }, {
      headers: {
        "Authorization": \`Bearer \${OPENAI_API_KEY}\`,
        "Content-Type": "application/json"
      }
    });

    const output = completion.data.choices[0].message.content.trim();
    res.json({ output });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;