const hre = require("hardhat");

async function main() {
  const Marketplace = await hre.ethers.getContractFactory("AqroNFTMarketplace");
  const market = await Marketplace.deploy();
  await market.deployed();
  console.log("Marketplace deployed to:", market.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});