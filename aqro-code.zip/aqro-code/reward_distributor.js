const { ethers } = require("ethers");
const fs = require("fs");

// Load ABI files
const nftAbi = require("./abi/petrium_nft.json");
const tokenAbi = require("./abi/petrium_token.json");
const db = require("./db");

// Setup
const provider = new ethers.JsonRpcProvider("https://sepolia.infura.io/v3/YOUR_INFURA_KEY");
const wallet = new ethers.Wallet("YOUR_PRIVATE_KEY", provider);
const nftContract = new ethers.Contract("NFT_CONTRACT_ADDRESS", nftAbi, wallet);
const tokenContract = new ethers.Contract("TOKEN_CONTRACT_ADDRESS", tokenAbi, wallet);

async function distributeRewards() {
  const referrals = await db.referrals.find({}).toArray();

  for (const ref of referrals) {
    const count = ref.invited.length;
    if (count >= 5 && !ref.rewarded5) {
      console.log("Rewarding:", ref.wallet);

      // Mint NFT
      const tx1 = await nftContract.safeMint(ref.wallet, "ipfs://badge_inviter_5_metadata.json");
      await tx1.wait();

      // Transfer PTR
      const tx2 = await tokenContract.transfer(ref.wallet, ethers.parseUnits("50", 18));
      await tx2.wait();

      await db.referrals.updateOne({ code: ref.code }, { $set: { rewarded5: true } });
    }

    if (count >= 10 && !ref.rewarded10) {
      const tx3 = await nftContract.safeMint(ref.wallet, "ipfs://badge_inviter_10_metadata.json");
      await tx3.wait();

      const tx4 = await tokenContract.transfer(ref.wallet, ethers.parseUnits("100", 18));
      await tx4.wait();

      await db.referrals.updateOne({ code: ref.code }, { $set: { rewarded10: true } });
    }
  }

  console.log("✅ پاداش‌ها توزیع شدند.");
}

distributeRewards();