// backend/api/market/listNFT.js

const express = require('express');
const router = express.Router();
const db = require('../../db');

router.post('/list', async (req, res) => {
  const { sellerWallet, tokenId, price, image, name, description } = req.body;

  if (!sellerWallet || !tokenId || !price || !image || !name) {
    return res.status(400).json({ error: 'Missing fields' });
  }

  try {
    await db.marketListings.insertOne({
      sellerWallet,
      tokenId,
      price,
      image,
      name,
      description,
      date: new Date()
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;