// backend/api/nava/navaRecommend.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/recommend', async (req, res) => {
  const { mood } = req.body;
  if (!mood) return res.status(400).json({ error: 'Missing mood' });

  const prompt = \`
Suggest a music track suitable for a user feeling \${mood}. Respond only with the track name and one sentence description.
\`;

  try {
    const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7
    }, {
      headers: {
        "Authorization": \`Bearer \${OPENAI_API_KEY}\`,
        "Content-Type": "application/json"
      }
    });

    const message = completion.data.choices[0].message.content;
    const track = message.split('
')[0] || 'Unknown Track';

    const trackUrl = 'https://file-examples.com/storage/fe7b71f8ecbfc129fa702d5/2017/11/file_example_MP3_1MG.mp3';

    res.json({ track, url: trackUrl });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;