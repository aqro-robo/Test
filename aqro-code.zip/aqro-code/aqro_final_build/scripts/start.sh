#!/bin/bash
cd backend && npm install && node index.js
