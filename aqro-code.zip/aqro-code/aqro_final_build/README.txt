This is the full Aqro final build project structure.
