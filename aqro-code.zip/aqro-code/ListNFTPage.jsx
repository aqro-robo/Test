import React, { useState } from 'react';
import axios from 'axios';

export default function ListNFTPage() {
  const [wallet, setWallet] = useState('');
  const [tokenId, setTokenId] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [result, setResult] = useState(null);

  const handleList = async () => {
    try {
      const res = await axios.post('/api/market/list', {
        sellerWallet: wallet,
        tokenId,
        price,
        image,
        name,
        description
      });
      setResult({ success: true });
    } catch (err) {
      setResult({ success: false, message: err.response?.data?.error || err.message });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-10">
      <h1 className="text-3xl font-bold mb-6">📤 لیست‌کردن NFT برای فروش</h1>

      <div className="max-w-md mx-auto space-y-4">
        <input type="text" placeholder="آدرس کیف پول" value={wallet} onChange={e => setWallet(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />
        <input type="text" placeholder="توکن ID" value={tokenId} onChange={e => setTokenId(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />
        <input type="text" placeholder="قیمت (PTR)" value={price} onChange={e => setPrice(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />
        <input type="text" placeholder="لینک تصویر NFT" value={image} onChange={e => setImage(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />
        <input type="text" placeholder="نام NFT" value={name} onChange={e => setName(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />
        <textarea placeholder="توضیحات NFT" value={description} onChange={e => setDescription(e.target.value)} className="w-full p-2 bg-gray-800 rounded" />

        <button onClick={handleList} className="w-full bg-blue-600 hover:bg-blue-700 p-2 rounded text-white font-semibold">📤 ثبت برای فروش</button>

        {result && (
          <div className="mt-6 p-4 bg-gray-900 border border-gray-700 rounded">
            {result.success ? (
              <p className="text-green-400">✅ با موفقیت ثبت شد!</p>
            ) : (
              <p className="text-red-400">❌ خطا: {result.message}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}