import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function MarketplacePage() {
  const [nfts, setNfts] = useState([]);
  const [wallet, setWallet] = useState('');
  const [buying, setBuying] = useState(null);

  const loadNFTs = async () => {
    const res = await axios.get('/api/market/nfts');
    setNfts(res.data);
  };

  const handleBuy = async (id) => {
    setBuying(id);
    try {
      const res = await axios.post('/api/market/buy', {
        buyerWallet: wallet,
        nftId: id
      });
      alert("✅ خرید موفق! Tx: " + res.data.txHash);
      loadNFTs();
    } catch (err) {
      alert("❌ خطا: " + (err.response?.data?.error || err.message));
    }
    setBuying(null);
  };

  useEffect(() => {
    loadNFTs();
  }, []);

  return (
    <div className="bg-black text-white min-h-screen p-10">
      <h1 className="text-3xl font-bold mb-6">🛒 NFT Marketplace</h1>

      <div className="mb-6 max-w-md">
        <label>کیف پول شما:</label>
        <input type="text" value={wallet} onChange={e => setWallet(e.target.value)} className="w-full p-2 bg-gray-800 rounded mt-2" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {nfts.map(nft => (
          <div key={nft.id} className="border border-gray-700 rounded p-4 bg-gray-900">
            <img src={nft.image} alt={nft.name} className="w-full h-48 object-cover rounded" />
            <h2 className="text-xl mt-4">{nft.name}</h2>
            <p className="text-gray-400 text-sm mt-1">{nft.description}</p>
            <p className="text-green-400 mt-2">💰 قیمت: {nft.price} PTR</p>
            <button
              onClick={() => handleBuy(nft.id)}
              disabled={buying === nft.id}
              className="mt-4 w-full bg-blue-600 hover:bg-blue-700 p-2 rounded">
              {buying === nft.id ? "⏳ در حال خرید..." : "🛒 خرید"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}