// backend/api/market/marketController.js

const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const db = require('../../db');
const nftAbi = require('../../abi/petrium_nft.json');

const NFT_CONTRACT = '0xNFT_CONTRACT_ADDRESS';
const ADMIN_WALLET = '0xADMIN_WALLET';
const provider = new ethers.JsonRpcProvider('https://sepolia.infura.io/v3/YOUR_INFURA_KEY');
const wallet = new ethers.Wallet('YOUR_PRIVATE_KEY', provider);
const nft = new ethers.Contract(NFT_CONTRACT, nftAbi, wallet);

// Mock data: replace with DB in future
const nftList = [
  {
    id: 'badge_inviter_5',
    name: 'Badge Inviter 5',
    description: 'Awarded for inviting 5 users.',
    image: 'https://ipfs.io/ipfs/badge_inviter_5_image',
    tokenId: 101,
    price: '50'
  },
  {
    id: 'badge_special_001',
    name: 'Special Collector',
    description: 'Limited edition badge for collectors.',
    image: 'https://ipfs.io/ipfs/special_badge_image',
    tokenId: 102,
    price: '75'
  }
];

router.get('/nfts', async (req, res) => {
  res.json(nftList);
});

router.post('/buy', async (req, res) => {
  const { buyerWallet, nftId } = req.body;
  const nftItem = nftList.find(n => n.id === nftId);
  if (!buyerWallet || !nftItem) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  try {
    const tx = await nft['safeTransferFrom(address,address,uint256)'](
      ADMIN_WALLET,
      buyerWallet,
      nftItem.tokenId
    );
    await tx.wait();

    await db.marketTxs.insertOne({
      buyerWallet,
      nftId,
      price: nftItem.price,
      txHash: tx.hash,
      date: new Date()
    });

    res.json({ success: true, txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;