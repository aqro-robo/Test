import React, { useState } from 'react';
import axios from 'axios';

export default function PetrosChatPage() {
  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);

  const userInfo = {
    username: 'giovanny',
    level: 4,
    nfts: ['badge_inviter_5', 'badge_special_001']
  };

  const speak = (text) => {
    const synth = window.speechSynthesis;
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'en-US';
    utter.rate = 1;
    synth.speak(utter);
  };

  const sendMessage = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setMessages(prev => [...prev, { role: 'user', content: question }]);
    try {
      const res = await axios.post('/api/ai/petros/ask', { question, userInfo });
      const answer = res.data.answer;
      setMessages(prev => [...prev, { role: 'petros', content: answer }]);
      speak(answer);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'petros', content: '❌ خطا در پاسخ‌دهی.' }]);
    }
    setQuestion('');
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-4">🤖 گفت‌وگو با Petros</h1>

      <div className="bg-gray-900 p-4 rounded h-[70vh] overflow-y-auto mb-4">
        {messages.map((msg, i) => (
          <div key={i} className={`mb-3 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block px-4 py-2 rounded ${msg.role === 'user' ? 'bg-blue-700' : 'bg-gray-700'}`}>
              {msg.content}
            </span>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          value={question}
          onChange={e => setQuestion(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage()}
          className="flex-grow p-2 bg-gray-800 rounded"
          placeholder="سؤالتو از پتروس بپرس..."
        />
        <button onClick={sendMessage} disabled={loading} className="bg-green-600 hover:bg-green-700 p-2 rounded">
          {loading ? '⏳...' : 'ارسال'}
        </button>
      </div>
    </div>
  );
}