import React, { useState } from 'react';
import axios from 'axios';

export default function MivaraPersonalityPage() {
  const [form, setForm] = useState({
    name: '', values: '', memories: '', hobbies: '', tone: ''
  });
  const [profile, setProfile] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const generateProfile = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/mivara/generate', form);
      setProfile(res.data.profile);
    } catch (err) {
      setProfile('❌ خطا در تولید شخصیت.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">🧠 Mivara – ساخت شخصیت دیجیتال</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <input name="name" value={form.name} onChange={handleChange} placeholder="نام شخصیت" className="p-2 bg-gray-800 rounded" />
        <input name="values" value={form.values} onChange={handleChange} placeholder="ارزش‌ها و باورها" className="p-2 bg-gray-800 rounded" />
        <input name="memories" value={form.memories} onChange={handleChange} placeholder="خاطرات و تجربیات" className="p-2 bg-gray-800 rounded" />
        <input name="hobbies" value={form.hobbies} onChange={handleChange} placeholder="علایق یا سرگرمی‌ها" className="p-2 bg-gray-800 rounded" />
        <input name="tone" value={form.tone} onChange={handleChange} placeholder="لحن گفتار" className="p-2 bg-gray-800 rounded" />
      </div>

      <button
        onClick={generateProfile}
        disabled={loading}
        className="bg-purple-600 hover:bg-purple-700 p-2 rounded mb-6"
      >
        {loading ? '⏳ تولید شخصیت...' : '🔮 ساخت پروفایل شخصیت'}
      </button>

      {profile && (
        <div className="bg-gray-900 p-4 rounded text-violet-300 whitespace-pre-wrap">
          {profile}
        </div>
      )}
    </div>
  );
}