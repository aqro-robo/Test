import React, { useState } from 'react';
import axios from 'axios';

export default function ZentroxDashboardPage() {
  const [vpnConfig, setVpnConfig] = useState(null);
  const [loading, setLoading] = useState(false);

  const getVPN = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/zentrox/create');
      setVpnConfig(res.data);
    } catch (err) {
      setVpnConfig({ error: err.message });
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">🛡 Zentrox – امنیت و VPN شخصی</h1>

      <button
        onClick={getVPN}
        disabled={loading}
        className="bg-green-600 hover:bg-green-700 p-2 rounded mb-6"
      >
        {loading ? '⏳ در حال ساخت...' : 'دریافت VPN شخصی'}
      </button>

      {vpnConfig && vpnConfig.error && (
        <p className="text-red-400">❌ خطا: {vpnConfig.error}</p>
      )}

      {vpnConfig && vpnConfig.link && (
        <div className="bg-gray-900 p-4 rounded space-y-4">
          <p className="text-green-400">✅ VPN ساخته شد!</p>
          <p>🔗 لینک: <a href={vpnConfig.link} target="_blank" rel="noreferrer" className="text-blue-400">{vpnConfig.link}</a></p>
          <img src={vpnConfig.qr} alt="QR Code" className="w-64 h-64 bg-white rounded" />
        </div>
      )}
    </div>
  );
}