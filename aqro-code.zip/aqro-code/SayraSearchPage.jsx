import React, { useState } from 'react';
import axios from 'axios';

export default function SayraSearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const res = await axios.post('/api/ai/sayra/search', { query });
      setResults(res.data.results);
    } catch (err) {
      setResults([{ title: 'خطا', url: '', summary: err.message }]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">🔍 جست‌وجو با Sayra</h1>

      <div className="flex gap-2 mb-6">
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSearch()}
          placeholder="سؤالت را بنویس..."
          className="flex-grow p-2 bg-gray-800 rounded"
        />
        <button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700 p-2 rounded">
          {loading ? '⏳...' : 'جست‌وجو'}
        </button>
      </div>

      <div className="space-y-6">
        {results.map((item, i) => (
          <div key={i} className="bg-gray-900 p-4 rounded">
            <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 text-lg font-bold">
              {item.title}
            </a>
            <p className="text-gray-300 mt-2">{item.summary}</p>
          </div>
        ))}
      </div>
    </div>
  );
}