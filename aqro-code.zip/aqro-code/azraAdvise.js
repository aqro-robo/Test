// backend/api/azra/azraAdvise.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/advise', async (req, res) => {
  const { name, age, city, skills, goal } = req.body;

  if (!name || !age || !city || !skills || !goal) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const prompt = `
You are Azra, a financial advisor AI for the future. Based on the following user data:
- Name: ${name}
- Age: ${age}
- City: ${city}
- Skills: ${skills}
- Financial Goal: ${goal}

Provide a personalized plan in 4 bullet points:
1. Suggested income opportunities
2. Skills or tools to develop
3. Investment strategies
4. Long-term financial vision
`;

  try {
    const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.75
    }, {
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      }
    });

    const advice = completion.data.choices[0].message.content.trim();
    res.json({ advice });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;