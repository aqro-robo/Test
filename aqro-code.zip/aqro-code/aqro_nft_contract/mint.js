const { ethers } = require("hardhat");

async function main() {
  const contractAddress = "PASTE_CONTRACT_ADDRESS_HERE";
  const [deployer] = await ethers.getSigners();
  const contract = await ethers.getContractAt("AqroBadgeNFT", contractAddress);

  const to = "PASTE_USER_WALLET";
  const uri = "https://aqro.io/nft-assets/badge_inviter_5.json";

  const tx = await contract.mint(to, uri);
  await tx.wait();

  console.log("NFT minted to:", to);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});