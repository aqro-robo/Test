# Aqro Final Project

ساختار نهایی برای دیپلوی روی سرور `aqro.io`

## Backend APIs:
- /api/auth/
- /api/petros/chat
- /api/reela/search
- /api/sayra/query
- /api/zentrox/vpn
- /api/nava/recommend
- /api/azra/advise
- /api/mivara/generate
- /api/facebody/generate
- /api/prompt/tune

## How to Run (Backend):
1. Add `.env` file with:
   OPENAI_API_KEY=your-key-here
2. Run:
   ```bash
   npm install
   node index.js
   ```

## How to Run (Frontend):
```bash
cd frontend
npm install
npm run dev
```