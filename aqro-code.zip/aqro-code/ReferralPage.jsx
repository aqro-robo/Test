import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ReferralPage = () => {
  const [refCode, setRefCode] = useState('');
  const [invited, setInvited] = useState([]);
  const [copied, setCopied] = useState(false);

  const userId = "user123"; // باید از سیستم auth گرفته شود
  const wallet = "0xUserWalletAddress"; // از کیف پول واقعی کاربر

  const generateReferral = async () => {
    const res = await axios.post('/api/referral/generate', { userId, wallet });
    setRefCode(res.data.code);
  };

  const fetchReferralStatus = async (code) => {
    const res = await axios.get('/api/referral/status/' + code);
    setInvited(res.data.invited);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(`${window.location.origin}/?ref=${refCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    generateReferral().then(() => {
      if (refCode) fetchReferralStatus(refCode);
    });
  }, []);

  return (
    <div className="p-10 bg-black text-white min-h-screen">
      <h1 className="text-2xl font-bold mb-6">🎁 سیستم دعوت Aqro</h1>
      <div className="mb-6">
        <p>🔗 لینک دعوت اختصاصی:</p>
        <div className="bg-gray-800 p-2 rounded mt-2 flex items-center">
          <span className="text-green-400 mr-2">{window.location.origin}/?ref={refCode}</span>
          <button className="ml-auto bg-blue-600 px-4 py-1 rounded" onClick={copyToClipboard}>
            {copied ? "کپی شد!" : "📋 کپی لینک"}
          </button>
        </div>
      </div>

      <h2 className="text-xl mb-2">👥 دعوت‌شده‌ها:</h2>
      <table className="w-full text-left border border-gray-700">
        <thead>
          <tr className="bg-gray-800">
            <th className="p-2">آدرس کیف پول</th>
            <th className="p-2">تاریخ دعوت</th>
          </tr>
        </thead>
        <tbody>
          {invited.map((item, i) => (
            <tr key={i} className="border-t border-gray-700">
              <td className="p-2">{item.wallet}</td>
              <td className="p-2">{new Date(item.date).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-6">
        <p>🏆 تعداد دعوت موفق: <strong>{invited.length}</strong></p>
        <p>🎖 سطح پاداش فعلی: {invited.length >= 10 ? "سطح طلایی" : invited.length >= 5 ? "سطح نقره‌ای" : "سطح عادی"}</p>
      </div>
    </div>
  );
};

export default ReferralPage;