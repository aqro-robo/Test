import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import nftAbi from '../abi/petrium_nft.json';

const NFT_CONTRACT = '0xYOUR_NFT_CONTRACT_ADDRESS';

export default function BadgeGallery() {
  const [badges, setBadges] = useState([]);

  const loadBadges = async () => {
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const nft = new ethers.Contract(NFT_CONTRACT, nftAbi, provider);

    const balance = await nft.balanceOf(address);
    const ownedBadges = [];

    for (let i = 0; i < balance; i++) {
      const tokenId = await nft.tokenOfOwnerByIndex(address, i);
      const uri = await nft.tokenURI(tokenId);
      const metadata = await fetch(uri).then(res => res.json());
      ownedBadges.push({ tokenId: tokenId.toString(), metadata });
    }

    setBadges(ownedBadges);
  };

  useEffect(() => {
    loadBadges();
  }, []);

  return (
    <div className="p-10 bg-black text-white min-h-screen">
      <h1 className="text-3xl font-bold mb-6">🎖 Badge Gallery</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {badges.map((badge, i) => (
          <div key={i} className="p-4 border border-gray-700 rounded bg-gray-900">
            <img src={badge.metadata.image} alt={badge.metadata.name} className="w-full h-48 object-cover rounded" />
            <h2 className="mt-4 text-xl font-semibold">{badge.metadata.name}</h2>
            <p className="text-sm text-gray-400 mt-2">{badge.metadata.description}</p>
            <p className="text-xs text-gray-500 mt-1">Token ID: {badge.tokenId}</p>
          </div>
        ))}
      </div>
      <div className="mt-6">
        <p>✅ تعداد کل دستاوردها: {badges.length}</p>
        <p>🏅 سطح افتخار: {badges.length >= 10 ? "افسانه‌ای" : badges.length >= 5 ? "حرفه‌ای" : "مبتدی"}</p>
      </div>
    </div>
  );
}