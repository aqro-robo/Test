// backend/api/facebody/facebodyGenerate.js

const express = require('express');
const router = express.Router();
const path = require('path');

router.post('/generate', async (req, res) => {
  const { height, eyeColor, skinTone, bodyType, cyberDetails } = req.body;

  if (!height || !eyeColor || !skinTone || !bodyType || !cyberDetails) {
    return res.status(400).json({ error: 'Missing required physical data' });
  }

  // فرض: این خروجی یک مدل از پیش‌ساخته‌شده GLB را می‌دهد (در حالت تستی)
  // در نسخه نهایی باید از Stable Diffusion یا Blender CLI خروجی گرفته شود
  const modelUrl = "https://aqro.io/models/generated/preview.glb";

  res.json({
    message: "✅ مدل سه‌بعدی با موفقیت تولید شد",
    modelUrl,
    preview: "https://aqro.io/previews/face_example.png"
  });
});

module.exports = router;