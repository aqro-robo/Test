import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import nftAbi from '../abi/petrium_nft.json';
import marketAbi from '../abi/marketplace.json';

const NFT_CONTRACT = '0xYOUR_NFT_CONTRACT';
const MARKETPLACE_ADDRESS = '0xYOUR_MARKETPLACE_ADDRESS';

export default function ListForSale() {
  const [nfts, setNfts] = useState([]);
  const [price, setPrice] = useState('');
  const [selected, setSelected] = useState(null);

  const loadUserNFTs = async () => {
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const nft = new ethers.Contract(NFT_CONTRACT, nftAbi, provider);

    const balance = await nft.balanceOf(address);
    const ownedNFTs = [];

    for (let i = 0; i < balance; i++) {
      const tokenId = await nft.tokenOfOwnerByIndex(address, i);
      const uri = await nft.tokenURI(tokenId);
      const metadata = await fetch(uri).then(res => res.json());
      ownedNFTs.push({ tokenId: tokenId.toString(), uri, metadata });
    }

    setNfts(ownedNFTs);
  };

  const listNFT = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const market = new ethers.Contract(MARKETPLACE_ADDRESS, marketAbi, signer);
    const nft = new ethers.Contract(NFT_CONTRACT, nftAbi, signer);

    const tokenId = selected.tokenId;
    const parsedPrice = ethers.utils.parseEther(price);

    await nft.approve(MARKETPLACE_ADDRESS, tokenId);
    const tx = await market.list(NFT_CONTRACT, tokenId, parsedPrice);
    await tx.wait();
    alert("✅ NFT لیست شد!");
    setSelected(null);
    setPrice('');
  };

  useEffect(() => {
    loadUserNFTs();
  }, []);

  return (
    <div className="p-10 bg-black text-white min-h-screen">
      <h1 className="text-2xl font-bold mb-4">📤 لیست‌کردن NFT برای فروش</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {nfts.map((nft, i) => (
          <div
            key={i}
            onClick={() => setSelected(nft)}
            className={`p-4 border ${selected?.tokenId === nft.tokenId ? 'border-green-500' : 'border-gray-600'} rounded cursor-pointer`}
          >
            <img src={nft.metadata.image} alt="" className="h-48 w-full object-cover rounded" />
            <h2 className="text-lg font-semibold mt-2">{nft.metadata.name}</h2>
            <p className="text-sm text-gray-400">{nft.tokenId}</p>
          </div>
        ))}
      </div>
      {selected && (
        <div className="mt-6">
          <h3 className="text-xl mb-2">💰 قیمت فروش (ETH):</h3>
          <input
            type="text"
            className="bg-gray-800 p-2 rounded w-40 text-white"
            value={price}
            onChange={e => setPrice(e.target.value)}
          />
          <button
            className="ml-4 bg-blue-600 px-4 py-2 rounded"
            onClick={listNFT}
          >
            📤 لیست برای فروش
          </button>
        </div>
      )}
    </div>
  );
}