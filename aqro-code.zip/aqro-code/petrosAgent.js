// backend/api/ai/petrosAgent.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/ask', async (req, res) => {
  const { question, userInfo } = req.body;
  if (!question || !userInfo) return res.status(400).json({ error: 'Missing data' });

  const prompt = `
You are Petros, a hyper-intelligent AI robot assistant in the Aqro system. You provide cinematic, insightful and personalized responses.

User Data:
- Username: ${userInfo.username}
- Level: ${userInfo.level}
- NFTs: ${userInfo.nfts.join(', ')}

Question: ${question}
Respond as Petros with a personalized answer.
`;

  try {
    const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.8
    }, {
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      }
    });

    const answer = completion.data.choices[0].message.content;
    res.json({ answer });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;