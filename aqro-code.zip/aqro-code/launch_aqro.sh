#!/bin/bash

# -----------------------------
# Aqro Final Launch Installer
# Domain: aqro.io
# -----------------------------

echo "🚀 Launching Aqro Project on aqro.io..."

# Update & install required packages
sudo apt update && sudo apt install -y nginx nodejs npm git certbot python3-certbot-nginx

# Clone repo if needed (replace if repo exists)
# git clone https://your_repo_url.git /var/www/aqro || echo "🔁 Repo already exists"

# Set up frontend
cd /var/www/aqro/frontend || exit 1
npm install
npm run build

# Copy build to nginx root
sudo rm -rf /var/www/html/*
sudo cp -r build/* /var/www/html/

# Backend setup
cd /var/www/aqro/backend || exit 1
npm install

# Start backend with pm2
sudo npm install -g pm2
pm2 start index.js --name aqro-api
pm2 save
pm2 startup

# Nginx config
sudo bash -c 'cat > /etc/nginx/sites-available/aqro <<EOF
server {
    listen 80;
    server_name aqro.io www.aqro.io;

    root /var/www/html;
    index index.html;

    location / {
        try_files $uri /index.html;
    }

    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF'

sudo ln -sf /etc/nginx/sites-available/aqro /etc/nginx/sites-enabled/aqro
sudo nginx -t && sudo systemctl restart nginx

# SSL setup
sudo certbot --nginx -d aqro.io -d www.aqro.io --non-interactive --agree-tos -m admin@aqro.io

echo "✅ Aqro is LIVE at https://aqro.io"