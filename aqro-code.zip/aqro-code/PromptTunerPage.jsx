import React, { useState } from 'react';
import axios from 'axios';

export default function PromptTunerPage() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setPrompt(e.target.value);

  const tunePrompt = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/prompt/tune', { prompt });
      setResponse(res.data.output);
    } catch (err) {
      setResponse('❌ خطا در بهینه‌سازی پرامپت.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">🧩 Auto-Prompt Tuner</h1>

      <textarea
        value={prompt}
        onChange={handleChange}
        placeholder="پرامپت خود را وارد کنید..."
        rows="6"
        className="w-full bg-gray-900 p-4 rounded mb-4"
      />

      <button
        onClick={tunePrompt}
        disabled={loading}
        className="bg-yellow-600 hover:bg-yellow-700 p-2 rounded mb-6"
      >
        {loading ? '⏳ در حال تحلیل...' : '⚙️ بهینه‌سازی پرامپت'}
      </button>

      {response && (
        <div className="bg-gray-800 p-4 rounded text-yellow-300 whitespace-pre-wrap">
          {response}
        </div>
      )}
    </div>
  );
}