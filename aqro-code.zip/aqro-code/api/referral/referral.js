const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../../db');

router.post('/generate', async (req, res) => {
  const { userId, wallet } = req.body;
  if (!userId || !wallet) return res.status(400).json({ error: 'Missing userId or wallet' });

  const code = uuidv4().split('-')[0];
  await db.referrals.insertOne({ code, userId, wallet, invited: [], createdAt: new Date() });
  res.json({ code });
});

router.post('/use', async (req, res) => {
  const { code, newUserId, wallet } = req.body;
  const referral = await db.referrals.findOne({ code });
  if (!referral) return res.status(404).json({ error: 'Invalid code' });

  await db.referrals.updateOne(
    { code },
    { $push: { invited: { userId: newUserId, wallet, date: new Date() } } }
  );
  res.json({ success: true });
});

router.get('/status/:code', async (req, res) => {
  const { code } = req.params;
  const referral = await db.referrals.findOne({ code });
  if (!referral) return res.status(404).json({ error: 'Not found' });
  res.json({ code, invited: referral.invited, total: referral.invited.length });
});

module.exports = router;