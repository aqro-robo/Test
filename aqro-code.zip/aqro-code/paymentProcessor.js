// backend/api/payment/paymentProcessor.js

const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const db = require('../../db');

const tokenAbi = require('../../abi/petrium_token.json');
const TOKEN_ADDRESS = '0xTOKEN_CONTRACT_ADDRESS';
const ADMIN_WALLET = '0xADMIN_WALLET';
const provider = new ethers.JsonRpcProvider('https://sepolia.infura.io/v3/YOUR_INFURA_KEY');
const wallet = new ethers.Wallet('YOUR_PRIVATE_KEY', provider);
const token = new ethers.Contract(TOKEN_ADDRESS, tokenAbi, wallet);

router.post('/pay', async (req, res) => {
  const { buyerWallet, amount, productId } = req.body;
  if (!buyerWallet || !amount || !productId)
    return res.status(400).json({ error: 'Missing fields' });

  try {
    const tx = await token.transferFrom(buyerWallet, ADMIN_WALLET, ethers.parseUnits(amount.toString(), 18));
    await tx.wait();

    await db.payments.insertOne({
      buyerWallet,
      productId,
      amount,
      txHash: tx.hash,
      date: new Date()
    });

    res.json({ success: true, txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;