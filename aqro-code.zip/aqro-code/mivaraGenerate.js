// backend/api/mivara/mivaraGenerate.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/generate', async (req, res) => {
  const { name, values, memories, hobbies, tone } = req.body;

  if (!name || !values || !memories || !hobbies || !tone) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const prompt = `
Create a digital personality profile named "${name}".
Include:
- Core values and beliefs: ${values}
- Key memories and life experiences: ${memories}
- Interests and hobbies: ${hobbies}
- Preferred tone of speech: ${tone}

Respond with a character summary including how it speaks, reacts, and behaves.
`;

  try {
    const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.85
    }, {
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      }
    });

    const profile = completion.data.choices[0].message.content.trim();
    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;