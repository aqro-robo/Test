import React from 'react';
import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <div className="p-10 flex flex-col items-center text-center">
        <h1 className="text-5xl font-bold mb-4 text-blue-400">🌐 Welcome to Aqro</h1>
        <p className="text-lg text-gray-300 mb-6 max-w-2xl">
          Aqro is an intelligent digital world powered by AI robots, personalized interaction, NFT rewards, and a cinematic Web3 experience.
        </p>
        <div className="flex gap-4 mb-10">
          <Link to="/login" className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded text-white font-semibold">
            🚀 Get Started
          </Link>
          <Link to="/chat" className="bg-gray-800 hover:bg-gray-700 px-6 py-2 rounded text-white font-semibold">
            🤖 Try Petros
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl">
          {[
            { name: "Petros", desc: "Main AI assistant & guide", emoji: "🧠" },
            { name: "Reela", desc: "Entertainment & film advisor", emoji: "🎬" },
            { name: "Zentrox", desc: "VPN & privacy protection", emoji: "🛡" },
            { name: "Sayra", desc: "Smart search & assistant", emoji: "🔍" },
            { name: "Nava", desc: "Music AI & voice engine", emoji: "🎧" },
            { name: "Azra", desc: "Wealth-building advisor", emoji: "💰" }
          ].map((bot, i) => (
            <div key={i} className="p-6 border border-gray-700 rounded bg-gray-900 hover:shadow-lg transition">
              <h2 className="text-xl font-semibold mb-2 text-blue-300">{bot.emoji} {bot.name}</h2>
              <p className="text-sm text-gray-400">{bot.desc}</p>
            </div>
          ))}
        </div>

        <footer className="mt-20 text-sm text-gray-500">
          &copy; 2025 Aqro – All rights reserved.
        </footer>
      </div>
    </div>
  );
}