import React, { useState } from 'react';
import axios from 'axios';

export default function NavaPlayerPage() {
  const [trackUrl, setTrackUrl] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [loading, setLoading] = useState(false);

  const getRecommendation = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/nava/recommend', { mood: 'calm' });
      setRecommendation(res.data.track);
      setTrackUrl(res.data.url);
    } catch (err) {
      setRecommendation('خطا در دریافت پیشنهاد.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">🎵 Nava – پخش‌کننده موسیقی هوشمند</h1>

      <button
        onClick={getRecommendation}
        disabled={loading}
        className="bg-blue-600 hover:bg-blue-700 p-2 rounded mb-6"
      >
        {loading ? '⏳ دریافت پیشنهاد...' : '🎧 دریافت آهنگ پیشنهادی'}
      </button>

      {recommendation && <p className="mb-4 text-green-400">🎶 {recommendation}</p>}

      {trackUrl && (
        <audio controls className="w-full">
          <source src={trackUrl} type="audio/mpeg" />
          مرورگر شما پخش‌کننده صوتی را پشتیبانی نمی‌کند.
        </audio>
      )}
    </div>
  );
}