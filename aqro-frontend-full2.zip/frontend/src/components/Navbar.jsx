import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav>
      <Link to="/petros">Petros</Link>
      <Link to="/reela">Reela</Link>
      <Link to="/sayra">Sayra</Link>
      <Link to="/zentrox">Zentrox</Link>
      <Link to="/nava">Nava</Link>
      <Link to="/azra">Azra</Link>
      <Link to="/mivara">Mivara</Link>
      <Link to="/facebody">FaceBody</Link>
      <Link to="/prompttuner">PromptTuner</Link>
    </nav>
  );
}