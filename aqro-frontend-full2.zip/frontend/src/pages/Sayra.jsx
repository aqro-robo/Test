import React from 'react';
export default function Sayra() {
  return <div><h2>Sayra Page</h2></div>;
}