import React, { useState } from 'react';

export default function Petros() {
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [audioUrl, setAudioUrl] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResponse('Loading...');
    setAudioUrl('');

    try {
      const res = await fetch('/api/petros/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });

      const data = await res.json();
      setResponse(data.reply);
      if (data.audioUrl) {
        setAudioUrl(data.audioUrl);
      }
    } catch (error) {
      setResponse('Error contacting Petros API.');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Petros Chat</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Ask Petros anything..."
          style={{ width: '60%', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '8px 12px', marginLeft: '10px' }}>
          Send
        </button>
      </form>
      <div style={{ marginTop: '20px' }}>
        <strong>Response:</strong>
        <p>{response}</p>
        {audioUrl && (
          <audio controls autoPlay>
            <source src={audioUrl} type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
        )}
      </div>
    </div>
  );
}