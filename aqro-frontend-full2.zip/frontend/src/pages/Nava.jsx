import React from 'react';
export default function Nava() {
  return <div><h2>Nava Page</h2></div>;
}