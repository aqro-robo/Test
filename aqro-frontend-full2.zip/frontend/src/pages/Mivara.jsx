import React from 'react';
export default function Mivara() {
  return <div><h2>Mivara Page</h2></div>;
}