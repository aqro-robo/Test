import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ChatWithMongo from './pages/ChatWithMongo';

function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/mongochat/:partnerId" element={<ChatWithMongo userId="user123" partnerId="user456" />} />
      </Routes>
    </Router>
  );
}

export default AppRoutes;
