const express = require('express');
const router = express.Router();
const Message = require('../models/message_model');

// GET all messages between two users
router.get('/:from/:to', async (req, res) => {
  const { from, to } = req.params;
  const messages = await Message.find({
    $or: [
      { from, to },
      { from: to, to: from }
    ]
  }).sort({ timestamp: 1 });
  res.json(messages);
});

// POST new message
router.post('/send', async (req, res) => {
  const { from, to, text } = req.body;
  if (!from || !to || !text) return res.status(400).json({ error: 'Missing fields' });
  const newMessage = await Message.create({ from, to, text });
  res.json(newMessage);
});

module.exports = router;
