import React from 'react';
export default function Zentrox() {
  return <div><h2>Zentrox Page</h2></div>;
}