import React from 'react';
export default function Petros() {
  return <div><h2>Petros Page</h2></div>;
}