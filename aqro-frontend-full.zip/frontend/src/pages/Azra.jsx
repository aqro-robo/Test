import React from 'react';
export default function Azra() {
  return <div><h2>Azra Page</h2></div>;
}