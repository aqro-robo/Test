import React from 'react';
export default function Reela() {
  return <div><h2>Reela Page</h2></div>;
}