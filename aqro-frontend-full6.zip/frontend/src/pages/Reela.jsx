import React, { useState } from 'react';

export default function Reela() {
  const [genre, setGenre] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResults([]);

    try {
      const res = await fetch('/api/reela/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ genre }),
      });
      const data = await res.json();
      setResults(data.suggestions || []);
    } catch (err) {
      setResults([{ title: 'Error', description: 'Failed to fetch suggestions' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Reela – Movie & Series Suggestions</h2>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          value={genre}
          onChange={(e) => setGenre(e.target.value)}
          placeholder="Enter a genre (e.g. sci-fi, drama, action)"
          style={{ width: '60%', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '8px 12px', marginLeft: '10px' }}>
          Search
        </button>
      </form>

      {loading && <p>Loading suggestions...</p>}

      <div style={{ marginTop: '20px' }}>
        {results.map((item, index) => (
          <div key={index} style={{ marginBottom: '12px' }}>
            <strong>{item.title}</strong>
            <p>{item.description}</p>
            {item.imdb && (
              <a href={item.imdb} target="_blank" rel="noopener noreferrer">
                IMDb
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}