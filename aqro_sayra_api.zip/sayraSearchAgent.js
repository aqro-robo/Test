// backend/api/ai/sayraSearchAgent.js

const express = require('express');
const router = express.Router();
const axios = require('axios');

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/search', async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'Missing query' });

  try {
    // ۱. ساخت نتایج جعلی برای تست اولیه (به جای Google API)
    const fakeResults = [
      {
        title: 'How AI is Changing the World',
        url: 'https://example.com/ai-world',
        content: 'AI is transforming industries, from healthcare to finance. It enables automation, personalized experiences, and predictive analytics.'
      },
      {
        title: 'The Future of Robotics',
        url: 'https://example.com/future-robotics',
        content: 'Robotics combined with AI will redefine human-machine interaction. Advancements in sensors, algorithms, and autonomy are key.'
      }
    ];

    // ۲. خلاصه‌سازی هر لینک با GPT
    const summaries = await Promise.all(fakeResults.map(async (item) => {
      const prompt = `Summarize the following text in 2 lines:

"${item.content}"`;
      const completion = await axios.post("https://api.openai.com/v1/chat/completions", {
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.5
      }, {
        headers: {
          "Authorization": `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        }
      });

      return {
        title: item.title,
        url: item.url,
        summary: completion.data.choices[0].message.content.trim()
      };
    }));

    res.json({ results: summaries });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;