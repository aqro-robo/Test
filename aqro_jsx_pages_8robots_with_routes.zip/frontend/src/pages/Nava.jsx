import React, { useState } from 'react';

function Nava() {
  const [track, setTrack] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePlayMusic = async () => {
    if (!track.trim()) return;
    setLoading(true);
    setError('');
    setAudioUrl('');

    try {
      const response = await fetch('/api/nava/play', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ track }),
      });

      if (!response.ok) throw new Error('Music fetch failed');

      const data = await response.json();
      setAudioUrl(data.url || '');
    } catch (err) {
      setError('Could not fetch music. Try another track.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>🎵 Nava – AI Music Player</h2>
      <input
        type="text"
        placeholder="Type a mood, genre, or song name..."
        value={track}
        onChange={(e) => setTrack(e.target.value)}
        style={styles.input}
      />
      <button onClick={handlePlayMusic} style={styles.button} disabled={loading}>
        {loading ? 'Loading...' : 'Play'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {audioUrl && (
        <div style={styles.audioBox}>
          <audio controls src={audioUrl} style={styles.audioPlayer}>
            Your browser does not support the audio element.
          </audio>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1rem',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  audioBox: {
    marginTop: '2rem',
  },
  audioPlayer: {
    width: '100%',
  },
};

export default Nava;
