import React, { useState } from 'react';

function Zilat() {
  const [claim, setClaim] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCheckTruth = async () => {
    if (!claim.trim()) return;

    setLoading(true);
    setError('');
    setResponse('');

    try {
      const res = await fetch('/api/zilat/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claim }),
      });

      if (!res.ok) throw new Error('Verification failed');

      const data = await res.json();
      setResponse(data.result || 'No verdict returned.');
    } catch (err) {
      setError('Could not verify the claim. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>👁️‍🗨️ Zilat – Truth Detector</h2>
      <input
        type="text"
        placeholder="Enter a claim or belief..."
        value={claim}
        onChange={(e) => setClaim(e.target.value)}
        style={styles.input}
      />
      <button onClick={handleCheckTruth} style={styles.button} disabled={loading}>
        {loading ? 'Verifying...' : 'Verify Claim'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {response && (
        <div style={styles.result}>
          <p>{response}</p>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1rem',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  result: {
    marginTop: '2rem',
    backgroundColor: '#f0f0f0',
    padding: '1rem',
    borderRadius: '8px',
  },
};

export default Zilat;
