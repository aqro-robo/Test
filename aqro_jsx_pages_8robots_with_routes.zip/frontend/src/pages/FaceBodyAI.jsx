import React, { useState } from 'react';

function FaceBodyAI() {
  const [image, setImage] = useState(null);
  const [modelUrl, setModelUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImage(file);
    setModelUrl('');
    setError('');
    setLoading(true);

    const formData = new FormData();
    formData.append('image', file);

    try {
      const res = await fetch('/api/facebody/generate', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Failed to generate model');

      const data = await res.json();
      setModelUrl(data.modelUrl || '');
    } catch (err) {
      setError('Could not generate 3D model. Try another image.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>👤 Face & Body AI – 3D Model Generator</h2>
      <input type="file" accept="image/*" onChange={handleUpload} style={styles.input} />
      {loading && <p>Generating 3D model...</p>}
      {error && <p style={styles.error}>{error}</p>}
      {modelUrl && (
        <div style={styles.result}>
          <p>✅ Model generated successfully:</p>
          <a href={modelUrl} target="_blank" rel="noopener noreferrer">{modelUrl}</a>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    marginBottom: '1rem',
  },
  error: {
    color: 'red',
  },
  result: {
    marginTop: '1rem',
    backgroundColor: '#f0f0f0',
    padding: '1rem',
    borderRadius: '8px',
  },
};

export default FaceBodyAI;
