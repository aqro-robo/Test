import React, { useState } from 'react';

function Sayra() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!query.trim()) return;

    setLoading(true);
    setError('');
    setResults(null);

    try {
      const res = await fetch('/api/sayra/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });

      if (!res.ok) throw new Error('Failed to fetch');

      const data = await res.json();
      setResults(data.results || []);
    } catch (err) {
      setError('Error during search. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>🔍 Sayra – Smart Search</h2>
      <input
        type="text"
        placeholder="Type your search..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={styles.input}
      />
      <button onClick={handleSearch} style={styles.button} disabled={loading}>
        {loading ? 'Searching...' : 'Search'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {results && results.length > 0 && (
        <div style={styles.results}>
          {results.map((item, index) => (
            <div key={index} style={styles.card}>
              <h4>{item.title || 'No Title'}</h4>
              <p>{item.snippet || 'No Description'}</p>
              {item.link && (
                <a href={item.link} target="_blank" rel="noopener noreferrer">
                  Visit
                </a>
              )}
            </div>
          ))}
        </div>
      )}

      {results && results.length === 0 && !loading && <p>No results found.</p>}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1rem',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  results: {
    marginTop: '2rem',
  },
  card: {
    padding: '1rem',
    marginBottom: '1rem',
    backgroundColor: '#f1f1f1',
    borderRadius: '8px',
  },
};

export default Sayra;
