import React, { useState } from 'react';

function Zentrox() {
  const [vpnLink, setVpnLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGetVPN = async () => {
    setLoading(true);
    setError('');
    setVpnLink('');

    try {
      const response = await fetch('/api/zentrox/vpn', {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Failed to generate VPN');

      const data = await response.json();
      setVpnLink(data.link || '');
    } catch (err) {
      setError('Could not fetch VPN. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>🛡️ Zentrox – Secure VPN & Anonymous Browsing</h2>
      <p>Click below to generate your private VPN connection.</p>
      <button onClick={handleGetVPN} style={styles.button} disabled={loading}>
        {loading ? 'Generating...' : 'Generate VPN'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {vpnLink && (
        <div style={styles.result}>
          <p><strong>VPN Link:</strong> <a href={vpnLink} target="_blank" rel="noopener noreferrer">{vpnLink}</a></p>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  result: {
    marginTop: '2rem',
    backgroundColor: '#f0f0f0',
    padding: '1rem',
    borderRadius: '8px',
  },
};

export default Zentrox;
