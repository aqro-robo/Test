import React, { useState } from 'react';

function PersonalityBuilder() {
  const [inputText, setInputText] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyzePersonality = async () => {
    if (!inputText.trim()) return;

    setLoading(true);
    setError('');
    setAnalysis('');

    try {
      const response = await fetch('/api/personality/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: inputText }),
      });

      if (!response.ok) throw new Error('Analysis failed');

      const data = await response.json();
      setAnalysis(data.analysis || 'No insights returned.');
    } catch (err) {
      setError('Could not analyze personality. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>🧠 Personality Builder – Deep Psychology Engine</h2>
      <textarea
        placeholder="Describe yourself or paste any of your writings..."
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        style={styles.textarea}
      />
      <button onClick={handleAnalyzePersonality} style={styles.button} disabled={loading}>
        {loading ? 'Analyzing...' : 'Analyze Personality'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {analysis && (
        <div style={styles.result}>
          <h4>🧬 Personality Insights</h4>
          <p>{analysis}</p>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  textarea: {
    width: '100%',
    height: '120px',
    fontSize: '1rem',
    padding: '10px',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  result: {
    marginTop: '2rem',
    backgroundColor: '#f0f0f0',
    padding: '1rem',
    borderRadius: '8px',
  },
};

export default PersonalityBuilder;
