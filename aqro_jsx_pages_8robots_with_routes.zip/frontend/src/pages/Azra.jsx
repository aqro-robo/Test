import React, { useState } from 'react';

function Azra() {
  const [topic, setTopic] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setError('');
    setSuggestions([]);

    try {
      const response = await fetch('/api/azra/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
      });

      if (!response.ok) throw new Error('Analysis failed');

      const data = await response.json();
      setSuggestions(data.suggestions || []);
    } catch (err) {
      setError('Could not analyze market. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>📊 Azra – Market Analyzer & Wealth Suggestions</h2>
      <input
        type="text"
        placeholder="Enter a topic, region or asset..."
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        style={styles.input}
      />
      <button onClick={handleAnalyze} style={styles.button} disabled={loading}>
        {loading ? 'Analyzing...' : 'Analyze'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {suggestions.length > 0 && (
        <div style={styles.results}>
          {suggestions.map((item, index) => (
            <div key={index} style={styles.card}>
              <p>{item}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1rem',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  results: {
    marginTop: '2rem',
  },
  card: {
    padding: '1rem',
    marginBottom: '1rem',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
  },
};

export default Azra;
