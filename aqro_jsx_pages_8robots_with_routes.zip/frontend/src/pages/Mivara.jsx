import React, { useState } from 'react';

function Mivara() {
  const [interests, setInterests] = useState('');
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateIdeas = async () => {
    if (!interests.trim()) return;
    setLoading(true);
    setError('');
    setIdeas([]);

    try {
      const response = await fetch('/api/mivara/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ interests }),
      });

      if (!response.ok) throw new Error('Failed to generate ideas');

      const data = await response.json();
      setIdeas(data.ideas || []);
    } catch (err) {
      setError('Could not generate ideas. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>💰 Mivara – Personal Income Generator</h2>
      <input
        type="text"
        placeholder="What are your skills or interests?"
        value={interests}
        onChange={(e) => setInterests(e.target.value)}
        style={styles.input}
      />
      <button onClick={handleGenerateIdeas} style={styles.button} disabled={loading}>
        {loading ? 'Generating...' : 'Get Ideas'}
      </button>

      {error && <p style={styles.error}>{error}</p>}

      {ideas.length > 0 && (
        <div style={styles.results}>
          {ideas.map((item, index) => (
            <div key={index} style={styles.card}>
              <p>{item}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '800px',
    margin: 'auto',
    fontFamily: 'Arial',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1rem',
    marginBottom: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '1rem',
  },
  results: {
    marginTop: '2rem',
  },
  card: {
    padding: '1rem',
    marginBottom: '1rem',
    backgroundColor: '#f5f5f5',
    borderRadius: '8px',
  },
};

export default Mivara;
