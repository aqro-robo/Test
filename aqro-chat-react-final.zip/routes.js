import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import ChatWithMongo from './pages/ChatWithMongo';
import SocketChat from './pages/SocketChat';
import ChatRouter from './pages/ChatRouter';

function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/mongochat/:partnerId" element={<ChatRouter currentUser="user123" />} />
        <Route path="/socket" element={<SocketChat userId="user123" token="YOUR_JWT_TOKEN" />} />
      </Routes>
    </Router>
  );
}

export default AppRoutes;
