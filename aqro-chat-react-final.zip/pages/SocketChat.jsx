import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const SocketChat = ({ userId, token }) => {
  const [socket, setSocket] = useState(null);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const newSocket = io('http://localhost:4000', {
      auth: { token }
    });
    setSocket(newSocket);

    newSocket.on('receiveMessage', (data) => {
      setMessages(prev => [...prev, data]);
    });

    return () => newSocket.disconnect();
  }, [token]);

  const sendMessage = () => {
    if (!input.trim() || !socket) return;
    const message = { from: userId, text: input, timestamp: new Date().toISOString() };
    socket.emit('sendMessage', message);
    setInput('');
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>⚡️ Real-Time Chat</h2>
      <div style={{ border: '1px solid #ccc', height: 300, overflowY: 'scroll', marginBottom: 10 }}>
        {messages.map((msg, idx) => (
          <div key={idx}><strong>{msg.from}:</strong> {msg.text}</div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Enter your message"
        style={{ width: '70%' }}
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
};

export default SocketChat;
