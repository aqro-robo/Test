import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppRoutes from './routes';

function App() {
  return (
    <Router>
      <div>
        <h1 style={styles.header}>🤖 Aqro Chat System</h1>
        <AppRoutes />
      </div>
    </Router>
  );
}

const styles = {
  header: {
    textAlign: 'center',
    padding: '1rem',
    background: '#111',
    color: '#0f0',
    fontFamily: 'Arial, sans-serif',
  },
};

export default App;
