const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Simulated chat storage
const chatFile = path.join(__dirname, '../../storage/chat.json');
if (!fs.existsSync(chatFile)) fs.writeFileSync(chatFile, JSON.stringify([]));

router.get('/chat/:uid/:tid', (req, res) => {
  const chatData = JSON.parse(fs.readFileSync(chatFile));
  const messages = chatData.filter(m =>
    (m.from === req.params.uid && m.to === req.params.tid) ||
    (m.from === req.params.tid && m.to === req.params.uid)
  );
  res.json(messages);
});

router.post('/chat/send', (req, res) => {
  const chatData = JSON.parse(fs.readFileSync(chatFile));
  chatData.push(req.body);
  fs.writeFileSync(chatFile, JSON.stringify(chatData, null, 2));
  res.json({ status: 'ok' });
});

module.exports = router;
