// Placeholder match logic (expand later with AI)
const users = [
  { id: "u1", name: "Alice", location: "Tehran", interests: ["tech", "music"] },
  { id: "u2", name: "Bob", location: "Tehran", interests: ["music", "finance"] },
];

function findMatches(currentUserId) {
  const user = users.find(u => u.id === currentUserId);
  if (!user) return [];
  return users.filter(u => u.id !== currentUserId && u.location === user.location);
}

module.exports = { findMatches };
