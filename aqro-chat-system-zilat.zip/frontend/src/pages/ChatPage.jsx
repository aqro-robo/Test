import React, { useState, useEffect } from 'react';

const ChatPage = ({ userId, targetId }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    fetch(`/api/chat/${userId}/${targetId}`)
      .then(res => res.json())
      .then(data => setMessages(data));
  }, [userId, targetId]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const msg = { from: userId, to: targetId, text: input };
    setMessages(prev => [...prev, msg]);
    setInput('');
    await fetch('/api/chat/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg)
    });
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🔁 Chat between {userId} & {targetId}</h2>
      <div style={{ border: '1px solid #ccc', height: 300, overflowY: 'auto', marginBottom: 10 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ padding: 5 }}>
            <strong>{msg.from}:</strong> {msg.text}
          </div>
        ))}
      </div>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Type a message..."
        style={{ width: '80%' }}
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
};

export default ChatPage;
