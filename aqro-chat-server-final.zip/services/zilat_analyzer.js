function analyzeMessageSet(messages) {
  let suspiciousCount = 0;
  const keywords = ["honestly", "trust me", "believe me", "I swear"];
  const contradictionWords = ["never", "always", "impossible"];

  for (const msg of messages) {
    const text = msg.text.toLowerCase();
    if (keywords.some(k => text.includes(k))) suspiciousCount++;
    if (contradictionWords.some(k => text.includes(k))) suspiciousCount++;
  }

  if (suspiciousCount === 0) return "Likely Truth";
  if (suspiciousCount < 3) return "Uncertain – Needs more context";
  return "Possible Lie / Contradiction Detected";
}

module.exports = { analyzeMessageSet };
