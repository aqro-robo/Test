const express = require('express');
const router = express.Router();
const { analyzeMessageSet } = require('../services/zilat_analyzer');

router.post('/analyze', async (req, res) => {
  const { messages } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid message data." });
  }
  const result = analyzeMessageSet(messages);
  res.json({ result });
});

module.exports = router;
