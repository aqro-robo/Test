const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const securityAdvice = async (req, res) => {
  const { context } = req.body;
  if (!context) return res.status(400).json({ error: 'Context required' });

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{
        role: 'user',
        content: `As an AI security advisor, suggest the best privacy tools and VPN options for the following case: ${context}`
      }]
    });

    const recommendations = gptRes.data.choices[0].message.content;
    res.json({ recommendations });
  } catch (err) {
    res.status(500).json({ error: 'Zentrox failed to generate tools' });
  }
};

module.exports = { securityAdvice };