import { useState } from 'react';
import axios from 'axios';

export default function Nava() {
  const [mood, setMood] = useState('');
  const [tracks, setTracks] = useState('');

  const getMusic = async () => {
    if (!mood) return;
    const res = await axios.post('/api/nava/music', { mood });
    setTracks(res.data.suggestions);
  };

  return (
    <div>
      <h2>🎧 Nava - Music Recommender</h2>
      <input value={mood} onChange={e => setMood(e.target.value)} placeholder="Enter your mood (e.g. relax, focus, party)" />
      <button onClick={getMusic}>Get Music</button>
      <pre>{tracks}</pre>
    </div>
  );
}