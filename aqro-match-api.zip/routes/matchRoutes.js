const express = require('express');
const router = express.Router();

function fakeAnalyze(user) {
  const data = {
    suggestions: [
      {
        name: "Lara_78",
        type: "emotional",
        matchPercent: 87,
        commonTraits: ["Introvert", "Music", "Late-night thinker"],
        location: "Tehran, Iran"
      },
      {
        name: "AlirezaTech",
        type: "professional",
        matchPercent: 91,
        commonTraits: ["AI Research", "Remote work", "Python"],
        location: "Isfahan, Iran"
      }
    ],
    analysis: {
      liarScore: Math.random() > 0.5 ? "Low" : "Moderate"
    }
  };
  return data;
}

router.post('/suggest', (req, res) => {
  const userData = req.body;
  const result = fakeAnalyze(userData);
  res.json(result);
});

module.exports = router;
