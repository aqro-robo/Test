const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

const matchRoutes = require('./routes/matchRoutes');

app.use(cors());
app.use(express.json());
app.use('/api/match', matchRoutes);

app.listen(port, () => {
  console.log(`🔗 Match API running at http://localhost:${port}`);
});
