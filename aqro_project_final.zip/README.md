# Aqro Full Project
This is a simulated full stack project structure.
