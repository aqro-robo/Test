const express = require('express');
const router = express.Router();
const User = require('../models/User');

// GET user
router.get('/info', async (req, res) => {
  const user = await User.findOne();
  if (!user) {
    const newUser = new User({ name: 'AqroUser', balance: 'Ξ 4.21' });
    await newUser.save();
    return res.json(newUser);
  }
  res.json(user);
});

// POST user update
router.post('/update', async (req, res) => {
  const data = req.body;
  let user = await User.findOne();
  if (!user) user = new User(data);
  else {
    user.name = data.name;
    user.balance = data.balance;
  }
  await user.save();
  res.json({ success: true, user });
});

module.exports = router;
