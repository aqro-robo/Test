const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const searchAnswer = async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'Query required' });

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{
        role: 'user',
        content: `Answer briefly and clearly: ${query}`
      }]
    });

    const answer = gptRes.data.choices[0].message.content;
    res.json({ answer });
  } catch (err) {
    res.status(500).json({ error: 'Search failed' });
  }
};

module.exports = { searchAnswer };