import { useState } from 'react';
import axios from 'axios';

export default function Reela() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState('');

  const search = async () => {
    if (!query) return;
    const res = await axios.post('/api/reela/search', { query });
    setResults(res.data.suggestions);
  };

  return (
    <div>
      <h2>🎬 Reela - Movie & Series Suggestions</h2>
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Enter a movie, theme or genre" />
      <button onClick={search}>Search</button>
      <pre>{results}</pre>
    </div>
  );
}