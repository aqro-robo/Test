import { useState } from 'react';
import axios from 'axios';

export default function Sayra() {
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState('');

  const search = async () => {
    if (!query) return;
    const res = await axios.post('/api/sayra/search', { query });
    setAnswer(res.data.answer);
  };

  return (
    <div>
      <h2>🔍 Sayra - Smart Search</h2>
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Ask a question..." />
      <button onClick={search}>Search</button>
      <p><b>Answer:</b> {answer}</p>
    </div>
  );
}