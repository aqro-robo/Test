const express = require('express');
const cors = require('cors');
const app = express();
const port = 4000;

app.use(cors());

const user = {
  name: 'AqroUser',
  balance: 'Ξ 4.21'
};

app.get('/api/user/info', (req, res) => {
  res.json(user);
});

app.listen(port, () => {
  console.log(`✅ Aqro User API running at http://localhost:${port}`);
});
