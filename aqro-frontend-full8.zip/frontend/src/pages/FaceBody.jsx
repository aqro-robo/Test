import React from 'react';
export default function FaceBody() {
  return <div><h2>FaceBody Page</h2></div>;
}