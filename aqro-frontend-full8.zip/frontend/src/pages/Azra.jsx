import React, { useState } from 'react';

export default function Azra() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchOpportunities = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResults([]);

    try {
      const res = await fetch('/api/azra/opportunities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: query }),
      });
      const data = await res.json();
      setResults(data.opportunities || []);
    } catch (err) {
      setResults([{ title: 'Error', description: 'Could not fetch opportunities.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Azra – Smart Business Advisor</h2>
      <form onSubmit={fetchOpportunities}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your location or interests (e.g. Tehran - tech)"
          style={{ width: '60%', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '8px 12px', marginLeft: '10px' }}>
          Get Suggestions
        </button>
      </form>

      {loading && <p>Loading suggestions...</p>}

      <div style={{ marginTop: '20px' }}>
        {results.map((item, index) => (
          <div key={index} style={{ marginBottom: '12px' }}>
            <strong>{item.title}</strong>
            <p>{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}