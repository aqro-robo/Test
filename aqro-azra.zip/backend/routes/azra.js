const express = require('express');
const router = express.Router();
const { suggestBusiness } = require('../controllers/azraController');

router.post('/business', suggestBusiness);

module.exports = router;