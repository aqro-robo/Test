const express = require('express');
const router = express.Router();
const { suggestMusic } = require('../controllers/navaController');

router.post('/music', suggestMusic);

module.exports = router;