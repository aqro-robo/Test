const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

const searchMovies = async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'Query required' });

  try {
    const gptRes = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{
        role: 'user',
        content: `Suggest top 5 movies or series like "${query}". Format: Title - Genre - Year - Short description.`
      }]
    });

    const suggestions = gptRes.data.choices[0].message.content;
    res.json({ suggestions });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch suggestions' });
  }
};

module.exports = { searchMovies };