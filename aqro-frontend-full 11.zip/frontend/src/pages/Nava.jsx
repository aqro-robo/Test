import React, { useState } from 'react';

export default function Nava() {
  const [mood, setMood] = useState('');
  const [musicUrl, setMusicUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const getMusic = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMusicUrl('');

    try {
      const res = await fetch('/api/nava/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood }),
      });
      const data = await res.json();
      setMusicUrl(data.url || '');
    } catch (err) {
      setMusicUrl('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Nava – Mood-based Music</h2>
      <form onSubmit={getMusic}>
        <input
          type="text"
          value={mood}
          onChange={(e) => setMood(e.target.value)}
          placeholder="Enter your mood (happy, calm, sad...)"
          style={{ width: '60%', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '8px 12px', marginLeft: '10px' }}>
          Get Music
        </button>
      </form>

      {loading && <p>Loading music...</p>}

      {musicUrl && (
        <div style={{ marginTop: '20px' }}>
          <audio controls autoPlay>
            <source src={musicUrl} type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
        </div>
      )}
    </div>
  );
}