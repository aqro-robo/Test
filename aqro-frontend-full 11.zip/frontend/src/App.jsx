import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Petros from './pages/Petros';
import Reela from './pages/Reela';
import Sayra from './pages/Sayra';
import Zentrox from './pages/Zentrox';
import Nava from './pages/Nava';
import Azra from './pages/Azra';
import Mivara from './pages/Mivara';
import FaceBody from './pages/FaceBody';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Petros />} />
        <Route path="/reela" element={<Reela />} />
        <Route path="/sayra" element={<Sayra />} />
        <Route path="/zentrox" element={<Zentrox />} />
        <Route path="/nava" element={<Nava />} />
        <Route path="/azra" element={<Azra />} />
        <Route path="/mivara" element={<Mivara />} />
        <Route path="/facebody" element={<FaceBody />} />
      </Routes>
    </Router>
  );
}

export default App;