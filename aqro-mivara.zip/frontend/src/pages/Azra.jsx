import { useState } from 'react';
import axios from 'axios';

export default function Azra() {
  const [form, setForm] = useState({
    name: '', age: '', skills: '', interests: '', location: ''
  });
  const [result, setResult] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const getIdeas = async () => {
    const res = await axios.post('/api/azra/business', form);
    setResult(res.data.ideas);
  };

  return (
    <div>
      <h2>💸 Azra - Business & Wealth Advisor</h2>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="age" placeholder="Age" onChange={handleChange} />
      <input name="skills" placeholder="Skills (comma-separated)" onChange={handleChange} />
      <input name="interests" placeholder="Interests (comma-separated)" onChange={handleChange} />
      <input name="location" placeholder="Location" onChange={handleChange} />
      <button onClick={getIdeas}>Get Business Ideas</button>
      <pre>{result}</pre>
    </div>
  );
}