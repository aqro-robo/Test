import { useState } from 'react';
import axios from 'axios';

export default function Zentrox() {
  const [context, setContext] = useState('');
  const [result, setResult] = useState('');

  const getTools = async () => {
    if (!context) return;
    const res = await axios.post('/api/zentrox/tools', { context });
    setResult(res.data.recommendations);
  };

  return (
    <div>
      <h2>🛡️ Zentrox - Digital Privacy Advisor</h2>
      <input value={context} onChange={e => setContext(e.target.value)} placeholder="Enter your situation or need..." />
      <button onClick={getTools}>Get Privacy Tools</button>
      <pre>{result}</pre>
    </div>
  );
}