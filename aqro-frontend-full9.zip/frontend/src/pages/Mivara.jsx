import React, { useState } from 'react';

export default function Mivara() {
  const [description, setDescription] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const analyzePersonality = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult('');

    try {
      const res = await fetch('/api/mivara/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description }),
      });
      const data = await res.json();
      setResult(data.analysis || 'No result returned.');
    } catch (err) {
      setResult('Error analyzing personality.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Mivara – Personality & Artistic Style</h2>
      <form onSubmit={analyzePersonality}>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe yourself (e.g. I'm creative and love performing...)"
          style={{ width: '100%', height: '120px', padding: '10px' }}
        />
        <button type="submit" style={{ padding: '10px 20px', marginTop: '10px' }}>
          Analyze
        </button>
      </form>

      {loading && <p>Analyzing...</p>}

      {result && (
        <div style={{ marginTop: '20px', whiteSpace: 'pre-wrap' }}>
          <strong>Analysis Result:</strong>
          <p>{result}</p>
        </div>
      )}
    </div>
  );
}