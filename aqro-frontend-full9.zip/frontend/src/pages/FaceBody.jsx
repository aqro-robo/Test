import React, { useState } from 'react';

export default function FaceBody() {
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [modelUrl, setModelUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const generateModel = async (e) => {
    e.preventDefault();
    setLoading(true);
    setModelUrl('');

    try {
      const res = await fetch('/api/facebody/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ age, gender, height, weight }),
      });
      const data = await res.json();
      setModelUrl(data.modelUrl || '');
    } catch (err) {
      setModelUrl('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Face & Body AI – Generate Your 3D Model</h2>
      <form onSubmit={generateModel}>
        <input
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          style={{ marginRight: '10px', padding: '8px' }}
        />
        <input
          type="text"
          placeholder="Gender"
          value={gender}
          onChange={(e) => setGender(e.target.value)}
          style={{ marginRight: '10px', padding: '8px' }}
        />
        <input
          type="text"
          placeholder="Height (cm)"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          style={{ marginRight: '10px', padding: '8px' }}
        />
        <input
          type="text"
          placeholder="Weight (kg)"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          style={{ padding: '8px' }}
        />
        <br />
        <button type="submit" style={{ marginTop: '10px', padding: '10px 20px' }}>
          Generate Model
        </button>
      </form>

      {loading && <p>Generating model...</p>}

      {modelUrl && (
        <div style={{ marginTop: '20px' }}>
          <p><strong>3D Model:</strong></p>
          <a href={modelUrl} target="_blank" rel="noopener noreferrer">{modelUrl}</a>
          <p>(Copy link to view/download the model)</p>
        </div>
      )}
    </div>
  );
}