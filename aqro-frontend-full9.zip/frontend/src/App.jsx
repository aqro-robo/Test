import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Petros from './pages/Petros';
import Reela from './pages/Reela';
import Sayra from './pages/Sayra';
import Zentrox from './pages/Zentrox';
import Nava from './pages/Nava';
import Azra from './pages/Azra';
import Mivara from './pages/Mivara';
import FaceBody from './pages/FaceBody';
import PromptTuner from './pages/PromptTuner';
import Auth from './pages/Auth';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Auth />} />
        <Route path="/petros" element={<Petros />} />
        <Route path="/reela" element={<Reela />} />
        <Route path="/sayra" element={<Sayra />} />
        <Route path="/zentrox" element={<Zentrox />} />
        <Route path="/nava" element={<Nava />} />
        <Route path="/azra" element={<Azra />} />
        <Route path="/mivara" element={<Mivara />} />
        <Route path="/facebody" element={<FaceBody />} />
        <Route path="/prompttuner" element={<PromptTuner />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;