import React from 'react';
export default function Auth() {
  return <div><h2>Auth Page</h2></div>;
}