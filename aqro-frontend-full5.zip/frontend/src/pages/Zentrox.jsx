import React, { useState } from 'react';

export default function Zentrox() {
  const [vpnData, setVpnData] = useState(null);
  const [loading, setLoading] = useState(false);

  const getVPN = async () => {
    setLoading(true);
    setVpnData(null);
    try {
      const res = await fetch('/api/zentrox/vpn', { method: 'POST' });
      const data = await res.json();
      setVpnData(data);
    } catch (err) {
      setVpnData({ error: 'Failed to fetch VPN data.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Zentrox – Secure VPN Access</h2>
      <button onClick={getVPN} style={{ padding: '10px 20px' }}>
        {loading ? 'Generating VPN...' : 'Get VPN Access'}
      </button>

      {vpnData && (
        <div style={{ marginTop: '20px' }}>
          {vpnData.error && <p style={{ color: 'red' }}>{vpnData.error}</p>}
          {vpnData.link && (
            <>
              <p><strong>VPN Link:</strong> <a href={vpnData.link}>{vpnData.link}</a></p>
              {vpnData.qr && (
                <img src={vpnData.qr} alt="QR Code" style={{ width: '200px', marginTop: '10px' }} />
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}