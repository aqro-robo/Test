import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Home from './pages/Home';
import Petros from './pages/Petros';
import Reela from './pages/Reela';
import Sayra from './pages/Sayra';
import Zentrox from './pages/Zentrox';
import Azra from './pages/Azra';
import Nava from './pages/Nava';
import Zilat from './pages/Zilat';

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/petros" element={<Petros />} />
      <Route path="/reela" element={<Reela />} />
      <Route path="/sayra" element={<Sayra />} />
      <Route path="/zentrox" element={<Zentrox />} />
      <Route path="/azra" element={<Azra />} />
      <Route path="/nava" element={<Nava />} />
      <Route path="/zilat" element={<Zilat />} />
    </Routes>
  );
}

export default AppRoutes;
