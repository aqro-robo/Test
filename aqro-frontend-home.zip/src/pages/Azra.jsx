import React from 'react';
export default () => <div>Azra Page</div>;