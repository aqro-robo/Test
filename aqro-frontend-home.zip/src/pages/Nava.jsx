import React from 'react';
export default () => <div>Nava Page</div>;