import React from 'react';
export default () => <div>Sayra Page</div>;