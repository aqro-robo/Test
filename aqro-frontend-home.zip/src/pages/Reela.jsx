import React from 'react';
export default () => <div>Reela Page</div>;