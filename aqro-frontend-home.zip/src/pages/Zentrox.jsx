import React from 'react';
export default () => <div>Zentrox Page</div>;