import React from 'react';
export default () => <div>Petros Page</div>;