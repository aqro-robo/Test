# Aqro Final - Ready for Production

- Includes working .env file
- Backend and frontend folders
- Ready to unzip and run on your server