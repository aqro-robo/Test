// backend/api/zentrox/zentroxController.js

const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');

router.post('/create', async (req, res) => {
  try {
    // ساخت لینک V2Ray فرضی (تست)
    const vpnLink = 'vless://example@1.2.3.4:443?encryption=none&security=tls&type=ws#AqroVPN';

    // ساخت QR از لینک
    const qr = await QRCode.toDataURL(vpnLink);

    // پاسخ برگشتی
    res.json({ link: vpnLink, qr });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;